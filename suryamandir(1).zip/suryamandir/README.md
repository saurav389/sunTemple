# suryamandir
It is and web application of trust to raise the donation from all over India
